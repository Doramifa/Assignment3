package Assignment3;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;



class NewThread implements Runnable {

NewThread() {
	 try {
		    Document doc1 = Jsoup.connect("http://cs.whu.edu.cn/plus/view.php?aid=1628").get();
		    
		    Elements elements3 = doc1.select("[class=about_info fn_left]");
		    String teacher1=elements3.get(0).text();
		    System.out.println(teacher1);
		    
		    //�����txt
		    File fileout1 = new File("�¾�.txt");
		    OutputStreamWriter osr1 = new OutputStreamWriter(new FileOutputStream(fileout1), "UTF-8");
		    BufferedWriter br1 = new BufferedWriter(osr1);
		    br1.write(teacher1);
		    br1.flush();//ˢ�� 
		    br1.close();//�ر���
	      } catch (IOException e) {
	      System.out.println("Child interrupted.");
	  }
	  System.out.println("Exiting child thread.");
}

// �ڶ����߳����
public void run() {
   
  System.out.println("Exiting child thread.");
}
}


public class MultiThreading {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		new NewThread(); // ����һ�����߳�
		   try {
			    Document doc = Jsoup.connect("http://cs.whu.edu.cn/plus/view.php?aid=1627").get();
			    Elements elements1 = doc.select("[class=content fn_clear]");
			    
			    
			    Elements elements2 = elements1.select("[class=info_list]");
			    String teacher=elements2.get(0).text();
			    System.out.println(teacher);
			    
			    
			    File fileout = new File("�µ�.txt");
			    OutputStreamWriter osr = new OutputStreamWriter(new FileOutputStream(fileout), "UTF-8");
			    BufferedWriter br = new BufferedWriter(osr);
			    br.write(teacher);
			    br.flush();//ˢ�� 
			    br.close();//�ر���
		   } catch (IOException e) {
		      System.out.println("Main thread interrupted.");
		   }
		   System.out.println("Main thread exiting.");
		

	}

	
	
	

}






