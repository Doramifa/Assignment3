package Assignment3;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class Teacher {
public static void main(String[] args)throws IOException {
	    long startTime=System.currentTimeMillis();
	    try{
	    Document doc = Jsoup.connect("http://cs.whu.edu.cn/plus/view.php?aid=1627").get();
	    Elements elements1 = doc.select("[class=content fn_clear]");
	    
	    
	    Elements elements2 = elements1.select("[class=info_list]");
	    String teacher=elements2.get(0).text();
	    System.out.println(teacher);
	    
	    
	    File fileout = new File("�µ�.txt");
	    OutputStreamWriter osr = new OutputStreamWriter(new FileOutputStream(fileout), "UTF-8");
	    BufferedWriter br = new BufferedWriter(osr);
	    br.write(teacher);
	    br.flush();//ˢ�� 
	    br.close();//�ر���
	    
	    Document doc1 = Jsoup.connect("http://cs.whu.edu.cn/plus/view.php?aid=1628").get();
	    
	    Elements elements3 = doc1.select("[class=about_info fn_left]");
	    String teacher1=elements3.get(0).text();
	    System.out.println(teacher1);
	    
	    //�����txt
	    File fileout1 = new File("�¾�.txt");
	    OutputStreamWriter osr1 = new OutputStreamWriter(new FileOutputStream(fileout1), "UTF-8");
	    BufferedWriter br1 = new BufferedWriter(osr1);
	    br1.write(teacher1);
	    br1.flush();//ˢ�� 
	    br1.close();//�ر���
	    
        Document doc2 = Jsoup.connect("http://cs.whu.edu.cn/plus/view.php?aid=1626").get();
	    
	    Elements elements4 = doc2.select("[class=info_list_ct]");
	    String teacher2=elements4.get(0).text();
	    System.out.println(teacher2);
	    
	    //�����txt
	    File fileout2 = new File("������.txt");
	    OutputStreamWriter osr2 = new OutputStreamWriter(new FileOutputStream(fileout2), "UTF-8");
	    BufferedWriter br2 = new BufferedWriter(osr2);
	    br2.write(teacher2);
	    br2.flush();//ˢ�� 
	    br2.close();//�ر���
	    
        Document doc3 = Jsoup.connect("http://cs.whu.edu.cn/plus/view.php?aid=1625").get();
	    
	    Elements elements5 = doc3.select("[class=info_list_ct]");
	    String teacher3=elements5.get(0).text();
	    System.out.println(teacher3);
	    
	    //�����txt
	    File fileout3 = new File("������.txt");
	    OutputStreamWriter osr3 = new OutputStreamWriter(new FileOutputStream(fileout3), "UTF-8");
	    BufferedWriter br3 = new BufferedWriter(osr3);
	    br3.write(teacher3);
	    br3.flush();//ˢ�� 
	    br3.close();//�ر���
	    
        Document doc4 = Jsoup.connect("http://cs.whu.edu.cn/plus/view.php?aid=1623").get();
	    Elements elements7=doc4.select("[class=about_info fn_left]");
	    String teacher4=elements7.get(0).text();
	    System.out.println(teacher4);
	    Elements elements6 = doc4.select("[class=info_list_ct]");
	    String news=elements6.get(0).text();
	    System.out.println(news);
	    
	    //�����txt
	    File fileout4 = new File("����ӱ.txt");
	    OutputStreamWriter osr4 = new OutputStreamWriter(new FileOutputStream(fileout4), "UTF-8");
	    BufferedWriter br4 = new BufferedWriter(osr4);
	    br4.write(news);
	    br4.newLine();
	    br4.write(teacher4);
	    br4.flush();//ˢ�� 
	    br4.close();//�ر���
		}catch (IOException e) {
			e.printStackTrace();}
	    long endTime=System.currentTimeMillis();
	    System.out.println("��������ʱ�䣺 "+(endTime-startTime)+"ms");
	 }
     
}
    


